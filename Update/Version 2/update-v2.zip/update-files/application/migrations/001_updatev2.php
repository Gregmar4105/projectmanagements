<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Updatev2 extends CI_Migration {

    public function __construct() {
		parent::__construct();
		$this->load->dbforge();
    }
    
    public function up()
    {
        $this->db->set('class', 'warning');
        $this->db->where('id', 2);
        $this->db->update('priorities');

        $this->dbforge->add_field(array(
                'id' => array(
                        'type' => 'INT',
                        'constraint' => 11,
                        'unsigned' => TRUE,
                        'auto_increment' => TRUE
                ),
                'user_id' => array(
                        'type' => 'INT',
                        'constraint' => 11,
                ),
                'description' => array(
                        'type' => 'TEXT',
                        'null' => FALSE,
                ),
                'created datetime default current_timestamp',
        ));
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table('notes');

        

        $this->dbforge->add_field(array(
            'id' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => TRUE,
                    'auto_increment' => TRUE
            ),
            'user_id' => array(
                    'type' => 'INT',
                    'constraint' => 11,
            ),
            'done' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'default ' => 0,
            ),
            'todo' => array(
                    'type' => 'TEXT',
                    'null' => FALSE,
            ),
            'due_date' => array(
                    'type' => 'DATE',
                    'null' => FALSE,
            ),
            'created datetime default current_timestamp',
    ));
    $this->dbforge->add_key('id', TRUE);
    $this->dbforge->create_table('todo');

    }

    public function down()
    {
            $this->dbforge->drop_table('notes');
            $this->dbforge->drop_table('todo');
    }
}