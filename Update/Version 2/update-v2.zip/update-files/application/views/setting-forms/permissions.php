<form action="<?=base_url('settings/save-permissions-setting')?>" method="POST" id="setting-form">
                      <div class="card-body row">
                        <div class="alert alert-danger col-md-12 center">
                          <b>Note!</b> Admin always have all the permission. Here you can set permissions for team members/users.
                        </div>
                        <div class="form-group col-md-12">
                            <label class="d-block">Projects</label>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="project_view" value="<?=(isset($permissions->project_view) && !empty($permissions->project_view))?$permissions->project_view:0?>" <?=(isset($permissions->project_view) && !empty($permissions->project_view) && $permissions->project_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox1">View</label>
                            </div>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox2" name="project_create" value="<?=(isset($permissions->project_create) && !empty($permissions->project_create))?$permissions->project_create:0?>" <?=(isset($permissions->project_create) && !empty($permissions->project_create) && $permissions->project_create == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox2">Create</label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox3" name="project_edit" value="<?=(isset($permissions->project_edit) && !empty($permissions->project_edit))?$permissions->project_edit:0?>" <?=(isset($permissions->project_edit) && !empty($permissions->project_edit) && $permissions->project_edit == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox3">Edit</label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox4" name="project_delete" value="<?=(isset($permissions->project_delete) && !empty($permissions->project_delete))?$permissions->project_delete:0?>" <?=(isset($permissions->project_delete) && !empty($permissions->project_delete) && $permissions->project_delete == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox4">Delete</label>
                            </div>
                        </div>
                        <div class="form-group col-md-12">
                            <label class="d-block">Tasks</label>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox5" name="task_view" value="<?=(isset($permissions->task_view) && !empty($permissions->task_view))?$permissions->task_view:0?>" <?=(isset($permissions->task_view) && !empty($permissions->task_view) && $permissions->task_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox5">View</label>
                            </div>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox6" name="task_create" value="<?=(isset($permissions->task_create) && !empty($permissions->task_create))?$permissions->task_create:0?>" <?=(isset($permissions->task_create) && !empty($permissions->task_create) && $permissions->task_create == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox6">Create</label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox7" name="task_edit" value="<?=(isset($permissions->task_edit) && !empty($permissions->task_edit))?$permissions->task_edit:0?>" <?=(isset($permissions->task_edit) && !empty($permissions->task_edit) && $permissions->task_edit == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox7">Edit</label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox8" name="task_delete" value="<?=(isset($permissions->task_delete) && !empty($permissions->task_delete))?$permissions->task_delete:0?>" <?=(isset($permissions->task_delete) && !empty($permissions->task_delete) && $permissions->task_delete == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox8">Delete</label>
                            </div>
                        </div>
                      
                        <div class="form-group col-md-12">
                            <label class="d-block">ToDo 
                            </label>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox14" name="todo_view" value="<?=(isset($permissions->todo_view) && !empty($permissions->todo_view))?$permissions->todo_view:0?>" <?=(isset($permissions->todo_view) && !empty($permissions->todo_view) && $permissions->todo_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox14">View</label>
                            </div>
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label class="d-block">Notes 
                            </label>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox13" name="notes_view" value="<?=(isset($permissions->notes_view) && !empty($permissions->notes_view))?$permissions->notes_view:0?>" <?=(isset($permissions->notes_view) && !empty($permissions->notes_view) && $permissions->notes_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox13">View</label>
                            </div>
                        </div>

                        
                        <div class="form-group col-md-12">
                            <label class="d-block">Chat 
                            </label>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox12" name="chat_view" value="<?=(isset($permissions->chat_view) && !empty($permissions->chat_view))?$permissions->chat_view:0?>" <?=(isset($permissions->chat_view) && !empty($permissions->chat_view) && $permissions->chat_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox12">View</label>
                            </div>
                        </div>

                        <div class="form-group col-md-12">
                            <label class="d-block">Users 
                              <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="Only admin have permission to add, edit and delete users. You can make any user as admin they will get all this permissions by default."></i>
                            </label>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox9" name="user_view" value="<?=(isset($permissions->user_view) && !empty($permissions->user_view))?$permissions->user_view:0?>" <?=(isset($permissions->user_view) && !empty($permissions->user_view) && $permissions->user_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox9">View</label>
                            </div>
                        </div>
                        
                        <div class="form-group col-md-12">
                            <label class="d-block">Settings <i class="fas fa-question-circle" data-toggle="tooltip" data-placement="right" title="" data-original-title="Settings have some some sensetive information about application. Make sure you have proper knowledge about what permission you are giving to the users."></i></label>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox10" name="setting_view" value="<?=(isset($permissions->setting_view) && !empty($permissions->setting_view))?$permissions->setting_view:0?>" <?=(isset($permissions->setting_view) && !empty($permissions->setting_view) && $permissions->setting_view == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox10">View</label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="checkbox" id="inlineCheckbox11" name="setting_update" value="<?=(isset($permissions->setting_update) && !empty($permissions->setting_update))?$permissions->setting_update:0?>" <?=(isset($permissions->setting_update) && !empty($permissions->setting_update) && $permissions->setting_update == 1)?'checked':''?>>
                              <label class="form-check-label" for="inlineCheckbox11">Update</label>
                            </div>
                        </div>

                      </div>
                      <?php if ($this->ion_auth->is_admin() || permissions('setting_update')){ ?>
                        <div class="card-footer bg-whitesmoke text-md-right">
                          <button class="btn btn-primary savebtn">Save Changes</button>
                        </div>
                      <?php } ?>
                      <div class="result"></div>
                    </form>