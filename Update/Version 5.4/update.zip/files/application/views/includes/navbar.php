<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
  <ul class="navbar-nav mr-auto">
    <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
  </ul>
  <ul class="navbar-nav navbar-right">

    <?php if(!$this->ion_auth->in_group(3)){ ?>
      <li id="nav_timer" class="<?=(check_my_timer())?'':'d-none'?>"><a href="<?=base_url('projects/timesheet')?>" class="nav-link nav-link-lg beep" target="_blank"><i class="fas fa-stopwatch text-danger"></i></a></li>
    <?php } ?>


    <?php 
      $notifications = get_notifications();
      $new_noti = true;
      $show_beep_for_msg = false;
      $unread_msg_count = get_unread_msg_count();
      if(($this->ion_auth->is_admin() || permissions('chat_view')) && $unread_msg_count){
          $show_beep_for_msg = true;
      }

    ?>
    <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg <?=$notifications || $show_beep_for_msg?'beep':''?>"><i class="far fa-bell"></i></a>
      <div class="dropdown-menu dropdown-list dropdown-menu-right">
        <div class="dropdown-header">
          <?=$this->lang->line('notifications')?$this->lang->line('notifications'):'Notifications'?>
        </div>
        <div class="dropdown-list-content dropdown-list-icons">

        <?php if($show_beep_for_msg){ 
          $new_noti = false;
        ?> 
          <a href="<?=base_url('chat')?>" class="dropdown-item dropdown-item-unread">
          <figure class="dropdown-item-icon avatar avatar-m bg-primary text-white fa fa-comment-alt"></figure>
          <h6 class="dropdown-item-desc m-2">
            <?=$this->lang->line('new_message')?$this->lang->line('new_message'):'New Message'?>
          </h6>
          </a>
        <?php } ?>

        <?php if($notifications){ 
          $new_noti = false;
          foreach($notifications as $notification){
        ?>

          <a href="<?=$notification['notification_url']?>" class="dropdown-item dropdown-item-unread">
            <?php if(isset($notification['profile']) && !empty($notification['profile'])){ ?>
              <figure class="dropdown-item-icon avatar avatar-m bg-transparent">
                <img src="<?=base_url(UPLOAD_PROFILE.''.htmlspecialchars($notification['profile']))?>" alt="<?=htmlspecialchars($notification['first_name'])?> <?=htmlspecialchars($notification['last_name'])?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=htmlspecialchars($notification['first_name'])?> <?=htmlspecialchars($notification['last_name'])?>">
              </figure>
            <?php }else{ ?>
              <figure class="dropdown-item-icon avatar avatar-m bg-primary text-white" data-initial="<?=mb_substr(htmlspecialchars($notification['first_name']), 0, 1, "utf-8").''.mb_substr(htmlspecialchars($notification['last_name']), 0, 1, "utf-8")?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=htmlspecialchars($notification['first_name'])?> <?=htmlspecialchars($notification['last_name'])?>">
              </figure>
            <?php } ?>
            <div class="dropdown-item-desc  ml-2">
              <?=$notification['notification']?>
              <div class="time text-primary"><?=time_elapsed_string($notification['created'])?></div>
            </div>
          </a>
        <?php } }else{ if($new_noti){ ?>
          <a class="dropdown-item dropdown-item-unread">
          <div class="dropdown-item-desc  ml-2">
            <?=$this->lang->line('no_new_notifications')?$this->lang->line('no_new_notifications'):'No new notifications.'?>
          </div>
          </a>
        <?php } } ?>
        </div>
        <div class="dropdown-footer text-center">
          <a href="<?=base_url('notifications')?>"><?=$this->lang->line('view_all')?$this->lang->line('view_all'):'View All'?> <i class="fas fa-chevron-right"></i></a>
        </div>
      </div>
    </li>
  
    <li class="dropdown">
      <a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg">
      <i class="fa fa-language"></i>
      </a>
      <div class="dropdown-menu dropdown-menu-right">
        <?php $languages = get_languages();
          if($languages){
          foreach($languages as $language){  ?>
            <a href="<?=base_url('languages/change/'.$language['language'])?>" class="dropdown-item <?=$language['language']==$this->session->userdata('lang') || ($language['language'] == default_language() && !$this->session->userdata('lang'))?'active':''?>">
              <?=ucfirst($language['language'])?>
            </a>
        <?php } } ?>
      </div>
    </li>


    <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
      <?php if(isset($current_user->profile) && !empty($current_user->profile)){ ?>
          <img alt="image" src="<?=base_url(UPLOAD_PROFILE.''.htmlspecialchars($current_user->profile))?>" class="rounded-circle mr-1">
      <?php }else{ ?>
          <figure class="avatar mr-2 avatar-sm bg-danger text-white" data-initial="<?=mb_substr(htmlspecialchars($current_user->first_name), 0, 1, "utf-8").''.mb_substr(htmlspecialchars($current_user->last_name), 0, 1, "utf-8")?>"></figure>
      <?php } ?>
      <div class="d-sm-none d-lg-inline-block"><?=htmlspecialchars($current_user->first_name)?> <?=htmlspecialchars($current_user->last_name)?></div></a>
      <div class="dropdown-menu dropdown-menu-right">
        <a href="<?=base_url('users/profile')?>" class="dropdown-item has-icon <?=(current_url() == base_url('users/profile'))?'active':''?>">
          <i class="far fa-user"></i> <?=$this->lang->line('profile')?$this->lang->line('profile'):'Profile'?>
        </a>

        <?php if($this->ion_auth->in_group(3)){ ?>
          <a href="<?=base_url('users/company')?>" class="dropdown-item has-icon <?=(current_url() == base_url('users/company'))?'active':''?>">
            <i class="far fa-copyright"></i> <?=$this->lang->line('company')?$this->lang->line('company'):'Company'?>
          </a>
        <?php } ?>

        <div class="dropdown-divider"></div>
        <a href="<?=base_url('auth/logout')?>" class="dropdown-item has-icon text-danger">
          <i class="fas fa-sign-out-alt"></i> <?=$this->lang->line('logout')?$this->lang->line('logout'):'Logout'?>
        </a>
      </div>
    </li>
  </ul>
</nav>
<div class="main-sidebar sidebar-style-2">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="<?=base_url()?>"><img class="navbar-logos" alt="Logo" src="<?=base_url('assets/uploads/logos/'.full_logo())?>"></a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="<?=base_url()?>"><img class="navbar-logos" alt="Logo Half" src="<?=base_url('assets/uploads/logos/'.half_logo())?>"></a>
    </div>
    <ul class="sidebar-menu">
      <li <?=(current_url() == base_url('/'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url()?>"><i class="fas fa-home text-primary"></i> <span><?=$this->lang->line('dashboard')?$this->lang->line('dashboard'):'Dashboard'?></span></a></li>
      
      <?php if($this->ion_auth->is_admin() || permissions('project_view')){ ?> 
        <li <?=(current_url() == base_url('projects') || $this->uri->segment(2) == 'detail')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects')?>"><i class="fas fa-layer-group text-danger"></i> <span><?=$this->lang->line('projects')?$this->lang->line('projects'):'Projects'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('task_view')){ ?>  
        <li <?=(current_url() == base_url('projects/tasks') || $this->uri->segment(2) == 'tasks')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects/tasks')?>"><i class="fas fa-tasks text-success"></i> <span><?=$this->lang->line('tasks')?$this->lang->line('tasks'):'Tasks'?></span></a></li>
      <?php } ?>
      
      
      <?php if($this->ion_auth->is_admin() || permissions('meetings_view')){ ?> 
        <li <?=(current_url() == base_url('meetings'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('meetings')?>"><i class="fas fa-video text-dark"></i> <span><?=$this->lang->line('video_meetings')?$this->lang->line('video_meetings'):'Video Meetings'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('client_view')){ ?>  
        <li <?=(current_url() == base_url('users/client'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('users/client')?>"><i class="fas fa-handshake text-warning"></i> <span><?=$this->lang->line('clients')?$this->lang->line('clients'):'Clients'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('lead_view')){ ?>  
        <li <?=(current_url() == base_url('leads'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('leads')?>"><i class="fas fa-phone text-danger"></i> <span><?=$this->lang->line('leads')?$this->lang->line('leads'):'Leads'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || $this->ion_auth->in_group(3)){ ?>           
        <li class="dropdown <?=(current_url() == base_url('invoices/payments') || $this->uri->segment(2) == 'payments'|| current_url() == base_url('expenses'))?'active':''; ?>">
        <a class="nav-link has-dropdown" href="#"><i class="fas fa-credit-card text-info"></i> 
        <span><?=$this->lang->line('finance')?$this->lang->line('finance'):'Finance'?></span></a>
          <ul class="dropdown-menu">

            <li <?=(current_url() == base_url('invoices/payments') || $this->uri->segment(2) == 'payments')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('invoices/payments')?>"><?=$this->lang->line('payments')?$this->lang->line('payments'):'Payments'?><?=$this->ion_auth->is_admin()?' / '.($this->lang->line('income')?htmlspecialchars($this->lang->line('income')):'Income'):''?></a></li>

            <?php if($this->ion_auth->is_admin()){ ?>
              <li <?=(current_url() == base_url('expenses'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('expenses')?>"><?=$this->lang->line('expenses')?$this->lang->line('expenses'):'Expenses'?></a></li>
            <?php } ?>
          </ul>
        </li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || $this->ion_auth->in_group(3)){ ?>           
        <li class="dropdown <?=((current_url() == base_url('invoices') || current_url() == base_url('estimates') || current_url() == base_url('products') || current_url() == base_url('settings/taxes') || $this->uri->segment(1) == 'invoices' || $this->uri->segment(1) == 'estimates') && ($this->uri->segment(2) != 'payments'))?'active':''; ?>">
        <a class="nav-link has-dropdown" href="#"><i class="fas fa-shopping-cart text-success"></i> 
        <span><?=$this->lang->line('sales')?$this->lang->line('sales'):'Sales'?></span></a>
          <ul class="dropdown-menu">
            <li <?=(current_url() == base_url('invoices') || $this->uri->segment(1) == 'invoices' && ($this->uri->segment(2) != 'payments'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('invoices')?>"><?=$this->lang->line('invoices')?$this->lang->line('invoices'):'Invoices'?></a></li> 

            <li <?=(current_url() == base_url('estimates') || $this->uri->segment(1) == 'estimates')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('estimates')?>"><?=$this->lang->line('estimates')?$this->lang->line('estimates'):'Estimates'?></a></li> 

            <?php if($this->ion_auth->is_admin()){ ?>
              <li <?=(current_url() == base_url('products'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('products')?>"><?=$this->lang->line('products')?$this->lang->line('products'):'Products'?></a></li>
            <?php } ?>

            <?php if($this->ion_auth->is_admin()){ ?>
              <li <?=(current_url() == base_url('settings/taxes'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/taxes')?>"><?=$this->lang->line('taxes')?$this->lang->line('taxes'):'Taxes'?></a></li>
            <?php } ?>

          </ul>
        </li>
      <?php } ?>

      
      <?php if($this->ion_auth->is_admin() || permissions('user_view')){ ?> 
        <li <?=(current_url() == base_url('users'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('users')?>"><i class="fas fa-users text-dark"></i> <span><?=$this->lang->line('team_members')?$this->lang->line('team_members'):'Team Members'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('chat_view')){ ?>  
        <li <?=(current_url() == base_url('chat'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('chat')?>"><i class="fas fa-comment-alt text-primary"></i> <span><?=$this->lang->line('chat')?$this->lang->line('chat'):'Chat'?></span></a></li>
      <?php } ?>

      <?php if(!$this->ion_auth->in_group(3)){ ?>  
        <li <?=(current_url() == base_url('projects/timesheet') || $this->uri->segment(2) == 'timesheet')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects/timesheet')?>"><i class="fas fa-clock text-info"></i> <span><?=$this->lang->line('timesheet')?$this->lang->line('timesheet'):'Timesheet'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('gantt_view')){ ?>  
        <li <?=(current_url() == base_url('projects/gantt') || $this->uri->segment(2) == 'gantt')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects/gantt')?>"><i class="fas fa-layer-group text-success"></i> <span><?=$this->lang->line('gantt')?$this->lang->line('gantt'):'Gantt'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('calendar_view')){ ?>  
        <li <?=(current_url() == base_url('projects/calendar') || $this->uri->segment(2) == 'calendar')?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('projects/calendar')?>"><i class="fas fa-calendar-alt text-danger"></i> <span><?=$this->lang->line('calendar')?$this->lang->line('calendar'):'Calendar'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('todo_view')){ ?>  
        <li <?=(current_url() == base_url('todo'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('todo')?>"><i class="fas fa-tasks text-warning"></i> <span><?=$this->lang->line('todo')?$this->lang->line('todo'):'ToDo'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin() || permissions('notes_view')){ ?>  
        <li <?=(current_url() == base_url('notes'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('notes')?>"><i class="fas fa-sticky-note text-info"></i> <span><?=$this->lang->line('notes')?$this->lang->line('notes'):'Notes'?></span></a></li>
      <?php } ?>
        
      <?php if(!$this->ion_auth->in_group(3)){ ?>  
        <li <?=(current_url() == base_url('leaves'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('leaves')?>"><i class="fas fa-calendar-alt text-danger"></i> <span><?=$this->lang->line('leaves')?$this->lang->line('leaves'):'Leaves'?></span></a></li>
        <li <?=(current_url() == base_url('attendance'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('attendance')?>"><i class="fas fa-clipboard-check text-warning"></i> <span><?=$this->lang->line('attendance')?$this->lang->line('attendance'):'Attendance'?></span></a></li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin()){ ?>           
        <li class="dropdown <?=(current_url() == base_url('reports') || $this->uri->segment(1) == 'reports')?'active':''; ?>">
        <a class="nav-link has-dropdown" href="#"><i class="fas fa-chart-bar text-success"></i> 
        <span><?=$this->lang->line('reports')?$this->lang->line('reports'):'Reports'?></span></a>
          <ul class="dropdown-menu">
              <li <?=(current_url() == base_url('reports/income'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('reports/income')?>"><?=$this->lang->line('income')?$this->lang->line('income'):'Income'?></a></li>

              <li <?=(current_url() == base_url('reports/expenses'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('reports/expenses')?>"><?=$this->lang->line('expenses')?$this->lang->line('expenses'):'Expenses'?></a></li> 

              <li <?=(current_url() == base_url('reports'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('reports')?>"><?=$this->lang->line('income_vs_expenses')?$this->lang->line('income_vs_expenses'):'Income VS Expenses'?></a></li>
          </ul>
        </li>
      <?php } ?>

      <?php if($this->ion_auth->is_admin()){ ?>  

        <li class="dropdown <?=($this->uri->segment(1) == 'settings' || $this->uri->segment(1) == 'languages')?'active':''; ?>">
        <a class="nav-link has-dropdown" href="#"><i class="fas fa-cog text-dark"></i> 
        <span><?=$this->lang->line('settings')?$this->lang->line('settings'):'Settings'?></span></a>
          <ul class="dropdown-menu">

              <li <?=(current_url() == base_url('settings'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings')?>"><?=$this->lang->line('general')?$this->lang->line('general'):'General'?></a></li>
              
              <li <?=(current_url() == base_url('settings/company'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/company')?>"><?=$this->lang->line('company')?$this->lang->line('company'):'Company'?></a></li>

              <li <?=(current_url() == base_url('settings/payment'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/payment')?>"><?=$this->lang->line('payment_gateway')?$this->lang->line('payment_gateway'):'Payment Gateway'?></a></li>

              <li <?=(current_url() == base_url('settings/email'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/email')?>"><?=$this->lang->line('email')?$this->lang->line('email'):'Email'?></a></li>

              <li <?=(current_url() == base_url('settings/email-templates'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/email-templates')?>"><?=$this->lang->line('email_templates')?$this->lang->line('email_templates'):'Email Templates'?></a></li>

              <li <?=(current_url() == base_url('settings/user-permissions'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/user-permissions')?>"><?=$this->lang->line('user_permissions')?$this->lang->line('user_permissions'):'User Permissions'?></a></li>

              <li <?=(current_url() == base_url('languages'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('languages')?>"><?=$this->lang->line('languages')?$this->lang->line('languages'):'Languages'?></a></li>
              
              <li <?=(current_url() == base_url('settings/taxes'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/taxes')?>"><?=$this->lang->line('taxes')?$this->lang->line('taxes'):'Taxes'?></a></li>

              <li <?=(current_url() == base_url('settings/update'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/update')?>"><?=$this->lang->line('update')?$this->lang->line('update'):'Update'?></a></li>

              <li <?=(current_url() == base_url('settings/custom-code'))?'class="active"':''; ?>><a class="nav-link" href="<?=base_url('settings/custom-code')?>"><?=$this->lang->line('custom_code')?$this->lang->line('custom_code'):'Custom Code'?></a></li>

          </ul>
        </li>

      <?php } ?>
      
    </ul>
  </aside>
</div>