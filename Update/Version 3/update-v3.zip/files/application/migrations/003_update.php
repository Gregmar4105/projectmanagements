<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_update extends CI_Migration {

	public function __construct() {
		parent::__construct();
		$this->load->dbforge();
	}

	public function up() {  

		$fields = array(
			'client_id' => array('type' => 'INT', 'null' => TRUE, 'after' => 'id')
			);
		$this->dbforge->add_column('projects', $fields);
        
        $data = array(
			array('name' => "client",
			'description' => "Clients")
		);
        $this->db->insert_batch('groups', $data);
        
	}

	public function down() {
		$this->dbforge->drop_column('projects', 'client_id');
	}
}
