<?php
defined('BASEPATH') OR exit('No direct script access allowed');


function get_notifications($user_id = ''){

    $CI =& get_instance();
    $left_join = " LEFT JOIN users u ON n.from_id=u.id ";
    $query = $CI->db->query("SELECT n.*,u.first_name,u.last_name,u.profile FROM notifications n $left_join WHERE is_read=0 AND to_id=".$CI->session->userdata('user_id')." ORDER BY n.created DESC LIMIT 10");
    $notifications = $query->result_array();
    if($notifications){
        foreach($notifications as $key => $notification){
            $temp[$key] = $notification;

            $extra = '';
            $notification_url = base_url('notifications');
            $notification_txt = $notification['notification'];
            if($notification['type'] == 'offline_request' && $CI->ion_auth->in_group(3)){
                $notification_txt = $CI->lang->line('offline_bank_transfer_request_created_for_subscription_plan')?$CI->lang->line('offline_bank_transfer_request_created_for_subscription_plan')." ".$notification['notification']:"Offline / Bank Transfer request created for subscription plan ".$notification['notification'];
                $notification_url = base_url('plans/offline-requests');
                $plan = $CI->plans_model->get_plans($notification['type_id']);
                if($plan){
                    $extra = '<div class="text-small">
                        '.($CI->lang->line('plan')?$CI->lang->line('plan'):'Plan').': <span class="text-info">'.$plan[0]['title'].'</span> 
                    </div>'; 
                }
            }elseif($notification['type'] == 'new_plan' && $CI->ion_auth->in_group(3)){
                $notification_txt = $CI->lang->line('ordered_subscription_plan')?$CI->lang->line('ordered_subscription_plan')." ".$notification['notification']:"Ordered subscription plan ".$notification['notification'];
                $notification_url = base_url('plans/orders');
                $plan = $CI->plans_model->get_plans($notification['type_id']);
                if($plan){
                    $user = $CI->ion_auth->user($notification['from_id'])->row();
                    if($user){
                        $ADD = 'User: <span class="text-info">'.$user->first_name.' '.$user->last_name.'</span>';
                    }
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('plan')?$CI->lang->line('plan'):'Plan').': <span class="text-info">'.$plan[0]['title'].'</span> 
                        '.($CI->lang->line('transaction')?$CI->lang->line('transaction'):'Transaction').': <span class="text-info">'.$plan[0]['price'].'</span> 
                        '.$ADD.'
                    </div>';
                }
            }elseif($notification['type'] == 'new_user' && $CI->ion_auth->in_group(3)){
                $notification_txt = $CI->lang->line('new_user_registered')?$CI->lang->line('new_user_registered'):"New user registered.";
                $notification_url = base_url('users/saas');
                $user = $CI->ion_auth->user($notification['type_id'])->row();
                if($user){
                    $extra = '<div class="text-small">
                        '.($CI->lang->line('user')?$CI->lang->line('user'):'User').': <span class="text-info">'.$user->first_name.' '.$user->last_name.'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'offline_request' && $CI->ion_auth->is_admin()){
                
                $notification_txt = $CI->lang->line('your_offline_bank_transfer_request_accepted_for_subscription_plan')?$CI->lang->line('your_offline_bank_transfer_request_accepted_for_subscription_plan')." ".$notification['notification']:"Your Offline / Bank Transfer request accepted for subscription plan ".$notification['notification'];
                $notification_url = base_url('plans');
                $plan = $CI->plans_model->get_plans($notification['type_id']);
                if($plan){
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('plan')?$CI->lang->line('plan'):'Plan').': <span class="text-info">'.$plan[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'new_project'){
                $notification_txt = $CI->lang->line('new_project_created')?$CI->lang->line('new_project_created')." ".$notification['notification']:$notification['notification']." new project created.";
                $notification_url = base_url('projects/detail/'.$notification['type_id']);
                $project = $CI->projects_model->get_projects('',$notification['type_id']);
                if($project){
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$project[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'project_status'){
                $old_status = project_status('',$notification['notification']);
                $project = $CI->projects_model->get_projects('',$notification['type_id']);

                if($old_status && $project){
                    $notification_txt = $CI->lang->line('project_status_changed')?$CI->lang->line('project_status_changed').' <span class="text-info text-strike">'.$old_status[0]['title'].'</span> = <span class="text-info">'.$project[0]['project_status'].'</span>':'Project status changed. <span class="text-info text-strike">'.$old_status[0]['title'].'</span> = <span class="text-info">'.$project[0]['project_status'].'</span>';
                }

                $notification_url = base_url('projects/detail/'.$notification['type_id']);
                
                if($project){
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$project[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'project_file'){
                $notification_txt = $CI->lang->line('project_file_uploaded')?$notification['notification']." ".$CI->lang->line('project_file_uploaded'):$notification['notification']." project file uploaded.";
                $notification_url = base_url('projects/detail/'.$notification['type_id']);
                $project = $CI->projects_model->get_projects('',$notification['type_id']);
                if($project){
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$project[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'new_task'){
                $notification_txt = $CI->lang->line('task_assigned_you')?$notification['notification']." ".$CI->lang->line('task_assigned_you'):$notification['notification']." task assigned you.";
                $task = $CI->projects_model->get_tasks('',$notification['type_id']);
                if($task){
                    $notification_url = base_url('projects/tasks/'.$task[0]['project_id'].'/'.$notification['type_id']);
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$task[0]['project_title'].'</span> 
                    '.($CI->lang->line('task')?$CI->lang->line('task'):'Task').': <span class="text-info">'.$task[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'task_status'){
                $task_status_old = task_status($notification['notification']);
                $task = $CI->projects_model->get_tasks('',$notification['type_id']);

                if($task_status_old && $task){
                    $notification_txt = $CI->lang->line('task_status_changed')?($CI->lang->line('task_status_changed').' <span class="text-info text-strike">'.$task_status_old[0]['title'].'</span> = <span class="text-info">'.$task[0]['task_status'].'</span>'):('Task status changed. <span class="text-info text-strike">'.$task_status_old[0]['title'].'</span> = <span class="text-info">'.$task[0]['task_status'].'</span>');
                }
                
                if($task){
                    $notification_url = base_url('projects/tasks/'.$task[0]['project_id'].'/'.$notification['type_id']);
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$task[0]['project_title'].'</span> 
                    '.($CI->lang->line('task')?$CI->lang->line('task'):'Task').': <span class="text-info">'.$task[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'task_file'){
                $notification_txt = $CI->lang->line('task_file_uploaded')?$notification['notification']." ".$CI->lang->line('task_file_uploaded'):$notification['notification']." task file uploaded.";
                $task = $CI->projects_model->get_tasks('',$notification['type_id']);
                if($task){
                    $notification_url = base_url('projects/tasks/'.$task[0]['project_id'].'/'.$notification['type_id']);
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$task[0]['project_title'].'</span> 
                    '.($CI->lang->line('task')?$CI->lang->line('task'):'Task').': <span class="text-info">'.$task[0]['title'].'</span> 
                    </div>';
                }
            }elseif($notification['type'] == 'task_comment'){
                $notification_txt = $CI->lang->line('new_task_comment')?$CI->lang->line('new_task_comment')." ".$notification['notification']:"New task comment ".$notification['notification'];
                $task = $CI->projects_model->get_tasks('',$notification['type_id']);
                if($task){
                    $notification_url = base_url('projects/tasks/'.$task[0]['project_id'].'/'.$notification['type_id']);
                    $extra = '<div class="text-small">
                    '.($CI->lang->line('project')?$CI->lang->line('project'):'Project').': <span class="text-info">'.$task[0]['project_title'].'</span> 
                    '.($CI->lang->line('task')?$CI->lang->line('task'):'Task').': <span class="text-info">'.$task[0]['title'].'</span> 
                    </div>';
                }
            }
            $temp[$key]['notification_url'] = $notification_url;

            $temp[$key]['notification'] = $notification_txt.' '.$extra;
            
            $temp[$key]['first_name'] = $notification['first_name'];
            $temp[$key]['last_name'] = $notification['last_name'];
            $temp[$key]['profile'] = $notification['profile'];

        }
    }else{
        $temp = array();
    }

    if(!empty($temp)){
        return $temp;
    }else{
        return false;
    }
}

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

function recurse_copy($src,$dst) {
    $dir = opendir($src);
    @mkdir($dst);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($src . '/' . $file) ) {
                recurse_copy($src . '/' . $file,$dst . '/' . $file);
            }
            else {
                copy($src . '/' . $file,$dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}

function project_status($field = '', $status_id = ''){
    $CI =& get_instance();
    if(!empty($field)){
        $CI->db->select($field);
    }
    $CI->db->from('project_status');
    if(!empty($status_id)){
        $CI->db->where(['id'=>$status_id]);
    }
    $query = $CI->db->get();
    $data = $query->result_array();
    if(!empty($data)){
        foreach($data as $key => $project_title){
            $tmp[$key] = $project_title;
            if($project_title['title'] == 'Not Started'){
            $tmp[$key]['title'] = $CI->lang->line('not_started')?$CI->lang->line('not_started'):'Not Started';
            }elseif($project_title['title'] == 'On Going'){
            $tmp[$key]['title'] = $CI->lang->line('on_going')?$CI->lang->line('on_going'):'On Going';
            }elseif($project_title['title'] == 'Finished'){
            $tmp[$key]['title'] = $CI->lang->line('finished')?$CI->lang->line('finished'):'Finished';
            }
        }
        return $tmp;
    }else{
        return false;
    }
}

function priorities(){
    $CI =& get_instance();
    $CI->db->from('priorities');
    $query = $CI->db->get();
    $data = $query->result_array();
    if(!empty($data)){
        foreach($data as $key => $priority){
            $tmp[$key] = $priority;
            if($priority['title'] == 'Low'){
            $tmp[$key]['title'] = $CI->lang->line('low')?$CI->lang->line('low'):'Low';
            }elseif($priority['title'] == 'Medium'){
            $tmp[$key]['title'] = $CI->lang->line('medium')?$CI->lang->line('medium'):'Medium';
            }elseif($priority['title'] == 'High'){
            $tmp[$key]['title'] = $CI->lang->line('high')?$CI->lang->line('high'):'High';
            }
        }
        return $tmp;
    }else{
        return false;
    }
}

function task_status($id = ''){
    $CI =& get_instance();
    $CI->db->from('task_status');
    if(!empty($id)){
        $CI->db->where(['id'=>$id]);
    }
    $query = $CI->db->get();
    $data = $query->result_array();
    if(!empty($data)){
        foreach($data as $key => $task_title){
            $tmp[$key] = $task_title;
            if($task_title['title'] == 'Todo'){
            $tmp[$key]['title'] = $CI->lang->line('todo')?$CI->lang->line('todo'):'Todo';
            }elseif($task_title['title'] == 'In Progress'){
            $tmp[$key]['title'] = $CI->lang->line('in_progress')?$CI->lang->line('in_progress'):'In Progress';
            }elseif($task_title['title'] == 'In Review'){
            $tmp[$key]['title'] = $CI->lang->line('in_review')?$CI->lang->line('in_review'):'In Review';
            }elseif($task_title['title'] == 'Completed'){
            $tmp[$key]['title'] = $CI->lang->line('completed')?$CI->lang->line('completed'):'Completed';
            }
        }
        return $tmp;
    }else{
        return false;
    }
}

function get_languages($language_id = '', $language_name = ''){
    $CI =& get_instance();
    $languages = $CI->languages_model->get_languages($language_id, $language_name);
    if(empty($languages)){
        return false;
    }else{
        return $languages;
    }
}

function permissions($permissions_type = '')
{
    $CI =& get_instance();
    $CI->db->from('settings');
    if($CI->ion_auth->in_group(3)){
        $CI->db->where(['type'=>'clients_permissions']);
    }else{
        $CI->db->where(['type'=>'permissions']);
    }
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(empty($permissions_type)){
        return $data;
    }else{
        return $data->$permissions_type;
    }
} 

function users_permissions($permissions_type = '')
{
    $CI =& get_instance();
    $where_type = 'permissions';
    $CI->db->from('settings');
    $CI->db->where(['type'=>$where_type]);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(empty($permissions_type)){
        return $data;
    }else{
        if(isset($data->$permissions_type)){
            return $data->$permissions_type;
        }else{
            return false;
        }
    }
} 

function clients_permissions($permissions_type = '')
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'clients_permissions']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(empty($permissions_type)){
        return $data;
    }else{
        return $data->$permissions_type;
    }
} 

function get_system_version(){
    $CI =& get_instance();
    $CI->db->select('value');
    $CI->db->from('settings');
    $CI->db->where(['type'=>'system_version']);
    $query = $CI->db->get();
    $data = $query->result_array();
    if(!empty($data)){
        return $data[0]['value'];
    }else{
        return false;
    }
}

function get_count($field,$table,$where = ''){ 
    if(!empty($where))
        $where = "where ".$where;
        
    $CI =& get_instance();
    $query = $CI->db->query("SELECT COUNT(".$field.") as total FROM ".$table." ".$where." ");
    $res = $query->result_array();
    if(!empty($res)){
        return $res[0]['total'];
    }
    
}

function smtp_host()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'email']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }

    $data = json_decode($data[0]['value']);

    if(!empty($data->smtp_host)){
        return $data->smtp_host;
    }else{
        return false;
    }
} 

function smtp_port()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'email']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->smtp_port)){
        return $data->smtp_port;
    }else{
        return false;
    }
} 

function smtp_username()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'email']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->smtp_username)){
        return $data->smtp_username;
    }else{
        return false;
    }
}

function smtp_password()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'email']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->smtp_password)){
        return $data->smtp_password;
    }else{
        return false;
    }
}

function smtp_encryption()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'email']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->smtp_encryption)){
        return $data->smtp_encryption;
    }else{
        return false;
    }
}

function company_name()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->company_name)){
        return $data->company_name;
    }else{
        return 'Tim Work';
    }
} 

function company_email()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->company_email)){
        return $data->company_email;
    }else{
        return 'admin@admin.com';
    }
} 

function footer_text()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->footer_text)){
        return $data->footer_text;
    }else{
        return company_name().' '.date('Y').' All Rights Reserved';
    }
} 

function google_analytics()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->google_analytics)){
        return $data->google_analytics;
    }else{
        return false;
    }
} 

function mysql_timezone()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->mysql_timezone)){
        return $data->mysql_timezone;
    }else{
        return '-11:00';
    }
} 

function php_timezone()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->php_timezone)){
        return $data->php_timezone;
    }else{
        return 'Pacific/Midway';
    }
} 

function system_date_format_js()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->date_format_js)){
        return $data->date_format_js;
    }else{
        return 'd-m-yyyy';
    }
} 

function system_time_format_js()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->time_format_js)){
        return $data->time_format_js;
    }else{
        return 'hh:MM tt';
    }
} 

function count_days_btw_two_dates($today , $sec_date){
    $CI =& get_instance();
    $today=date_create($today);
    $sec_date=date_create($sec_date);
    $diff=date_diff($today,$sec_date);
    $data['days'] = $diff->format("%a");
    if($today < $sec_date || $today == $sec_date){
        $data['days_status'] = $CI->lang->line('left')?$CI->lang->line('left'):'Left';
    }else{
        $data['days_status'] = $CI->lang->line('overdue')?$CI->lang->line('overdue'):'Overdue';
    }
    return $data;
}

function format_date($date , $date_format){
    $date = date_create($date);
    return date_format($date,$date_format);
}

function system_date_format()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->date_format)){
        return $data->date_format;
    }else{
        return 'd-m-Y';
    }
} 

function system_time_format()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->time_format)){
        return $data->time_format;
    }else{
        return 'h:i A';
    }
} 

function full_logo()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->full_logo)){
        return $data->full_logo;
    }else{
        return 'logo.png';
    }
} 

function file_upload_format()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->file_upload_format)){
        return $data->file_upload_format;
    }else{
        return 'jpg|png';
    }
}


function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 

    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 

    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

function half_logo()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();

    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->half_logo)){
        return $data->half_logo;
    }else{
        return 'logo-half.png';
    }
} 

function favicon()
{
    $CI =& get_instance();
    $CI->db->from('settings');
    $CI->db->where(['type'=>'general']);
    $query = $CI->db->get();
    $data = $query->result_array();
    
    if(!$data){
        return false;
    }
    
    $data = json_decode($data[0]['value']);

    if(!empty($data->favicon)){
        return $data->favicon;
    }else{
        return 'favicon.png';
    }
} 


function time_formats(){
    $CI =& get_instance();
    $CI->db->from('time_formats');
    $query = $CI->db->get();
    $data = $query->result_array();
    if(!empty($data)){
        return $data;
    }else{
        return false;
    }
}

function date_formats(){
    $CI =& get_instance();
    $CI->db->from('date_formats');
    $query = $CI->db->get();
    $data = $query->result_array();
    if(!empty($data)){
        return $data;
    }else{
        return false;
    }
}

function timezones(){
    $list = DateTimeZone::listAbbreviations();
    $idents = DateTimeZone::listIdentifiers();
    
        $data = $offset = $added = array();
        foreach ($list as $abbr => $info) {
            foreach ($info as $zone) {
                if ( ! empty($zone['timezone_id'])
                    AND
                    ! in_array($zone['timezone_id'], $added)
                    AND 
                      in_array($zone['timezone_id'], $idents)) {
                    $z = new DateTimeZone($zone['timezone_id']);
                    $c = new DateTime(null, $z);
                    $zone['time'] = $c->format('H:i a');
                    $offset[] = $zone['offset'] = $z->getOffset($c);
                    $data[] = $zone;
                    $added[] = $zone['timezone_id'];
                }
            }
        }
    
        array_multisort($offset, SORT_ASC, $data);
        
        $i = 0;$temp = array();
        foreach ($data as $key => $row) {
            $temp[0] = $row['time'];
            $temp[1] = formatOffset($row['offset']);
            $temp[2] = $row['timezone_id'];
            $options[$i++] = $temp;
        }
        
        if(!empty($options)){
            return $options;
        }
}

function formatOffset($offset) {
    $hours = $offset / 3600;
    $remainder = $offset % 3600;
    $sign = $hours > 0 ? '+' : '-';
    $hour = (int) abs($hours);
    $minutes = (int) abs($remainder / 60);

    if ($hour == 0 AND $minutes == 0) {
        $sign = ' ';
    }
    return $sign . str_pad($hour, 2, '0', STR_PAD_LEFT).':'. str_pad($minutes,2, '0');
}

function is_my_project($id){
    $CI =& get_instance();
    $query = $CI->db->query("SELECT id FROM projects WHERE id=$id AND client_id=".$CI->session->userdata('user_id'));
    $res = $query->result_array();
    if(!empty($res)){
        return true;
    }else{
        return false;
    } 
}

?>