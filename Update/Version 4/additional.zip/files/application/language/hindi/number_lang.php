<?php
/**
* System messages translation for CodeIgniter(tm)
*
* @author	CodeIgniter community
* @copyright	Copyright (c) 2014-2019, British Columbia Institute of Technology (https://bcit.ca/)
* @license	http://opensource.org/licenses/MIT MIT License
* @link	https://codeigniter.com
*/
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['terabyte_abbr'] = 'टीबी';
$lang['gigabyte_abbr'] = 'जीबी';
$lang['megabyte_abbr'] = 'एमबी';
$lang['kilobyte_abbr'] = 'केबी';
$lang['bytes'] = 'बाइट्स';
