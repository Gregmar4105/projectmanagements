<?php
/**
 * System messages translation for CodeIgniter(tm)
 *
 * @author	CodeIgniter community
 * @copyright	Copyright (c) 2014-2019, British Columbia Institute of Technology (https://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['migration_none_found'] = 'Միգրացիան չի գտնվել։';
$lang['migration_not_found'] = 'Հետևյալ համարի միգրացիա չի գտնվել․ %s։';
$lang['migration_sequence_gap'] = 'Գոյություն ունի ճեղքվածք հետևյալ համարի միգրացիայի մոտակայքում․ %s։';
$lang['migration_multiple_version'] = 'Գոյություն ունեն նույն համարի մեկից ավելի միգրացիաներ․ %s։';
$lang['migration_class_doesnt_exist'] = '"%s" միգրացիայի կլասը չի գտնվել';
$lang['migration_missing_up_method'] = '"%s" միգրացիայի կլասում "up" մեթոդը բացակայում է։';
$lang['migration_missing_down_method'] = '"%s" միգրացիայի կլասում "down" մեթոդը բացակայում է։';
$lang['migration_invalid_filename'] = '"%s" միգրացիայի ֆայլը սխալ է անվանակոչվել։';
