<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{
	public $data = [];

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		if ($this->ion_auth->logged_in())
		{
			$this->data['page_title'] = 'Dashboard - '.company_name();
			$this->data['current_user'] = $this->ion_auth->user()->row();
			$this->data['project_status'] = project_status();
			$this->data['task_status'] = task_status();
			$this->load->view('home',$this->data);
		}else{
			redirect('auth', 'refresh');
		}
	}

}
